# Projet SeminaireMath

# Keybindings
	- Fl�ches de naviguation pour les translations
	- WASDQE pour les rotations
	- PO pour le scaling
	- L pour le shearing X-Y
	- K pour le shearing Y-Z
	- R reset le cube

# Probl�mes connus
Les rotations ne s'ajoutent pas entre elles. Lors de la multiplication des quaternions, le r�sultat �tait incompr�hensible, nous avons donc choisi de le retirer

# Groupe
C�line Leplongeon, Aymeric Masse, Paul Pattyn